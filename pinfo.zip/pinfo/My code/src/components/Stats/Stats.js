import React from 'react';
import './Stats.css';

const Stats = () => {
	return (
	  	    <div>
	  	    	<div className='white f3'>
		  	    	{'Total pin submissions: '}
	  	    	</div>
	  	    	<div className='white f1'>
		  	    	{'5'}
	  	    	</div>
	  	    </div>
	  	);
	}
export default Stats;